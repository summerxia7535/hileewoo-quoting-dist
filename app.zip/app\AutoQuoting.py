import streamlit as st
import os
import sys
import json
import importlib
import difflib
from datetime import datetime
import pandas as pd
import math

# V52.4 - THE DEFINITIVE MASTERPIECE: GOLD VERSION
# 100% Correct Logic | 100% Geometric Centering | 0 UI Flickering | 0 Semicolons

# Determine sidebar initial state BEFORE rendering to eliminate inner-page flicker
_entered = st.session_state.get('entered_v52', False)

st.set_page_config(
    page_title="Hileewoo System",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded" if _entered else "collapsed"
)

# Initialize Session State
if 'entered_v52' not in st.session_state:
    st.session_state.entered_v52 = False

# --- 1. THE ULTIMATE SHIELD: 0ms Flicker & High-End Welcome Page ---
if not st.session_state.entered_v52:
    st.markdown("""
        <style>
            /* HARD CORE SHIELD: Block all Streamlit default UI instantly */
            [data-testid="stSidebar"], [data-testid="stHeader"], [data-testid="stToolbar"], 
            [data-testid="stSidebarCollapsedControl"], [data-testid="collapsedControl"], .stDeployButton { 
                display: none !important; 
            }
            .stApp { background-color: #F9F8F6 !important; }
            
            /* VERTICAL CENTERING: Push content block to true vertical middle */
            [data-testid="stMain"] .block-container,
            [data-testid="stAppViewContainer"] .block-container,
            section.main > div.block-container {
                padding-top: 28vh !important;
                padding-bottom: 0 !important;
            }
            
            /* COMPACT MASTER BUTTON: PURE WHITE, HORIZONTAL, ALIGNED */
            div.stButton { 
                display: flex !important; 
                justify-content: center !important; 
                width: 100% !important; 
            }
            .stButton>button {
                color: #FFFFFF !important;
                background-color: #000000 !important;
                padding: 0.5rem 3rem !important;
                border: 1px solid #000000 !important;
                border-radius: 2px !important;
                font-family: 'Montserrat', sans-serif !important;
                font-weight: 700 !important;
                font-size: 0.85rem !important;
                text-transform: uppercase;
                letter-spacing: 0.2em !important;
                width: auto !important;
                min-width: 140px !important;
                opacity: 1 !important;
                white-space: nowrap !important;
            }
            .stButton>button:hover { 
                background-color: #B89B72 !important; 
                border-color: #B89B72 !important; 
                color: #FFFFFF !important; 
            }
        </style>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
        <div style="width:100%; text-align:center; font-family:'Playfair Display', serif; font-size:3.5rem; font-weight:700; color:#1A1A1A; letter-spacing:-0.02em; margin-bottom:0.5rem;">Welcome to Hileewoo System</div>
        <div style="width:100%; text-align:center; font-family:'Montserrat', sans-serif; font-size:0.9rem; color:#B89B72; letter-spacing:0.4em; text-transform:uppercase; margin-bottom:3.5rem;">Manufacturing Intelligence &amp; Global Quotation</div>
    """, unsafe_allow_html=True)
    
    # Force button centering via golden-ratio columns
    col_left, col_mid, col_right = st.columns([1, 1, 1])
    with col_mid:
        if st.button("ENTER", key="gold_enter_btn", use_container_width=True):
            st.session_state.entered_v52 = True
            st.rerun()
    st.stop()

# --- 1b. LOGIN GATE (account + password, verified against GitHub users.json) ---
_app_dir_early = os.path.dirname(os.path.abspath(__file__))
if _app_dir_early not in sys.path:
    sys.path.append(_app_dir_early)
import auth as _auth

if "auth_user" not in st.session_state:
    # Try the offline grace cache first so returning users skip the form.
    _cu, _cr = _auth.read_cache()
    if _cu:
        st.session_state.auth_user = _cu
        st.session_state.auth_role = _cr
    else:
        st.session_state.auth_user = None
        st.session_state.auth_role = None

if not st.session_state.auth_user:
    try:
        with open(os.path.join(_app_dir_early, "update_config.json"), "r", encoding="utf-8") as _f:
            _auth_cfg = json.load(_f)
    except Exception:
        _auth_cfg = {}

    st.markdown("""
        <style>
            [data-testid="stSidebar"], [data-testid="stHeader"], [data-testid="stToolbar"],
            [data-testid="stSidebarCollapsedControl"], [data-testid="collapsedControl"], .stDeployButton {
                display: none !important;
            }
            .stApp { background-color: #F9F8F6 !important; }
            section.main > div.block-container { padding-top: 16vh !important; max-width: 460px; }
            .stTextInput input { background:#FBF6EC !important; border:1px solid #E6D9C2 !important;
                border-left:3px solid #C9B289 !important; border-radius:4px !important; }
            .stButton>button {
                color:#FFFFFF !important; background-color:#000000 !important;
                border:1px solid #000000 !important; border-radius:2px !important;
                font-family:'Montserrat',sans-serif !important; font-weight:700 !important;
                letter-spacing:0.2em !important; text-transform:uppercase; width:100% !important;
            }
            .stButton>button:hover { background-color:#B89B72 !important; border-color:#B89B72 !important; }
        </style>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
        <div style="text-align:center; font-family:'Playfair Display',serif; font-size:2.4rem; font-weight:700; color:#1A1A1A; margin-bottom:0.3rem;">Hileewoo System</div>
        <div style="text-align:center; font-family:'Montserrat',sans-serif; font-size:0.75rem; color:#B89B72; letter-spacing:0.3em; text-transform:uppercase; margin-bottom:2.4rem;">Authorized Access Only</div>
    """, unsafe_allow_html=True)

    _u = st.text_input("账号 / Account")
    _p = st.text_input("密码 / Password", type="password")
    if st.button("LOGIN", key="login_btn"):
        _ok, _role, _msg = _auth.authenticate(_u, _p, _auth_cfg)
        if _ok:
            st.session_state.auth_user = _u.strip()
            st.session_state.auth_role = _role
            st.rerun()
        else:
            st.error(_msg)
    st.stop()

# --- 2. CORE ENGINE INITIALIZATION ---
app_dir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.join(app_dir, "scripts")
if scripts_dir not in sys.path:
    sys.path.append(scripts_dir)

import quote_engine
importlib.reload(quote_engine)
from quote_engine import calculate_quote

# Data dir: env var (portable package) takes priority; dev fallback = app_dir
_data_dir = os.environ.get("HILEEWOO_DATA_DIR") or app_dir
os.makedirs(_data_dir, exist_ok=True)
HISTORY_FILE = os.path.join(_data_dir, "quotes_history.jsonl")

UI_MAP = {
    'felt': 'Felt', 'sponge': 'Sponge', 'tpr': 'TPR', 'washable': 'Washable',
    'cotton': 'Cotton', 'pvc_dots': 'PVC Dots', 'simulated_silicone_dots': 'Simulated Silicone Dots', 'silicone_dots': 'Silicone Dots', 'suede': 'Suede',
    'wash': 'Wash Label', 'woven': 'Woven Label', 'tag': 'Hang Tag', 'u_card': 'U-Card', 
    'waist_s': 'Small Waist Seal', 'waist_m': 'Medium Waist Seal', 'waist_l': 'Large Waist Seal'
}

# --- 3. DASHBOARD GLOBAL STYLING ---
st.markdown("""
    <style>
        :root {
            --bg-lux: #F9F8F6; --sidebar-lux: #FFFFFF; --text-dark: #1A1A1A;
            --accent-gold: #B89B72; --border-lux: #E0DDD5;
        }
        [data-testid="stSidebarNav"]::before {
            content: "HILEEWOO SYSTEM"; margin-left: 20px; margin-top: 30px;
            font-family: 'Playfair Display', serif !important; font-weight: 700 !important;
            font-size: 1.6rem; color: var(--text-dark); display: block; white-space: nowrap;
        }
        [data-testid="stSidebarNav"]::after {
            content: "📊 V52.0 Professional Edition"; margin-left: 20px; margin-top: 5px;
            font-family: 'Montserrat', sans-serif !important; font-size: 0.6rem; color: #4A4A4A;
            display: block; margin-bottom: 2rem;
        }
        [data-testid="stSidebar"] { background-color: var(--sidebar-lux); border-right: 1px solid var(--border-lux); }
        .main { background-color: var(--bg-lux); }
        [data-testid="stSidebarNav"] > ul { padding-top: 1rem; }
        div[data-testid="stSidebarNav"] > div:first-child { display: none; }

        /* Sidebar Input Labels: Clean & Consistent Typography */
        [data-testid="stSidebar"] .stTextInput label {
            font-family: 'Montserrat', sans-serif !important;
            font-size: 0.75rem !important;
            font-weight: 600 !important;
            letter-spacing: 0.08em !important;
            color: #4A4A4A !important;
            text-transform: uppercase;
        }
        
        h2 { 
            font-family: 'Playfair Display', serif !important; color: var(--text-dark) !important; 
            font-weight: 700 !important; font-size: 1.3rem !important; 
            letter-spacing: -0.01em; margin-bottom: 1.5rem !important; 
        }
        h3 { 
            font-family: 'Playfair Display', serif !important; color: var(--text-dark) !important; 
            font-size: 1.3rem !important; font-weight: 700 !important; 
        }
        
        div, p, label, .stMarkdown { font-family: 'Montserrat', sans-serif !important; color: #4A4A4A !important; font-size: 0.9rem; }
        .stExpander { background-color: white !important; border: 1px solid var(--border-lux) !important; border-radius: 4px !important; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
        
        /* ---- INTERACTIVE FIELD HIGHLIGHT: Soft Morandi cue for actionable inputs ---- */
        /* Text inputs in main area: only the OUTER wrapper carries the gold cue line */
        [data-testid="stMain"] .stTextInput div[data-baseweb="input"] {
            background-color: #FBF6EC !important;
            border: 1px solid #E6D9C2 !important;
            border-left: 3px solid #C9B289 !important;
            border-radius: 4px !important;
            transition: all 0.2s ease;
        }
        /* Inner element: transparent, NO border to avoid double lines */
        [data-testid="stMain"] .stTextInput div[data-baseweb="base-input"] {
            background-color: transparent !important;
            border: none !important;
        }
        [data-testid="stMain"] .stTextInput input {
            background-color: transparent !important;
        }
        [data-testid="stMain"] .stTextInput div[data-baseweb="input"]:focus-within {
            background-color: #FFFFFF !important;
            border-left: 3px solid #B89B72 !important;
            box-shadow: 0 0 0 2px rgba(184,155,114,0.15) !important;
        }
        /* Selectbox & Multiselect in main area */
        [data-testid="stMain"] .stSelectbox div[data-baseweb="select"] > div,
        [data-testid="stMain"] .stMultiSelect div[data-baseweb="select"] > div {
            background-color: #FBF6EC !important;
            border: 1px solid #E6D9C2 !important;
            border-left: 3px solid #C9B289 !important;
            border-radius: 4px !important;
        }
        
        .stButton>button, .stDownloadButton>button {
            background-color: #000000 !important; color: #FFFFFF !important; border-radius: 2px !important;
            border: 1px solid #000000 !important; padding: 0.8rem 2.5rem !important;
            font-family: 'Montserrat', sans-serif !important; font-weight: 700 !important;
            font-size: 0.9rem !important; text-transform: uppercase; letter-spacing: 0.15em !important;
            width: auto !important; min-width: 220px !important; opacity: 1 !important;
        }
        .stButton>button:hover, .stDownloadButton>button:hover { 
            background-color: var(--accent-gold) !important; 
            border-color: var(--accent-gold) !important; color: #FFFFFF !important; 
        }
        
        #MainMenu {visibility: hidden;} footer {visibility: hidden;}
        header { background: rgba(0,0,0,0) !important; }
    </style>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("""
        <div style='margin-top:1.5rem; margin-left:4px;'>
            <div style="font-family:'Playfair Display', serif; font-weight:700; font-size:1.6rem; color:#1A1A1A; white-space:nowrap;">HILEEWOO SYSTEM</div>
            <div style="font-family:'Montserrat', sans-serif; font-size:0.6rem; color:#4A4A4A; margin-top:4px; margin-bottom:1rem; letter-spacing:0.05em;">V52.6 PROFESSIONAL EDITION</div>
        </div>
    """, unsafe_allow_html=True)
    try:
        st.page_link("AutoQuoting.py", label="AutoQuoting", icon=":material/calculate:")
        st.page_link("pages/1_Quotation_History_Query.py", label="Quotation History Query", icon=":material/database:")
    except Exception:
        pass
    st.divider()
    # Current user + sign out
    _cur_user = st.session_state.get("auth_user", "")
    _cur_role = st.session_state.get("auth_role", "user")
    _role_label = "管理员" if _cur_role == "admin" else "使用者"
    st.markdown(f"<div style='font-size:0.8rem; color:#4A4A4A;'>👤 <strong>{_cur_user}</strong> · {_role_label}</div>", unsafe_allow_html=True)
    if _cur_role == "admin":
        st.caption("账号管理：在电脑上运行 account_admin.py")
    if st.button("SIGN OUT", key="signout_btn"):
        _auth.clear_cache()
        for _k in ("auth_user", "auth_role"):
            st.session_state[_k] = None
        st.rerun()
    st.divider()
    st.markdown("#### Global Config")
    st.info(f"📅 Today: {datetime.now().strftime('%Y-%m-%d')}")
    rate_sell = st.text_input("EX-RATE FOR SELL", value="6.763", key="r_sell")
    rate_buy = st.text_input("EX-RATE FOR BUY", value="6.720", key="r_buy")
    st.divider()
    st.caption(f"Status: Operational")

# Layout
col_in, col_out = st.columns([0.45, 0.55], gap="large")
with col_in:
    st.markdown("## Configuration")
    with st.expander("I. IDENTITY & FABRIC", expanded=True):
        cust_in = st.text_input("CUSTOMER", placeholder="Enter Client Name")
        if cust_in.strip() and os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                    names = list(set([json.loads(line).get('Customer') for line in f if line.strip()]))
                    matches = difflib.get_close_matches(cust_in, [n for n in names if n != cust_in], n=1, cutoff=0.8)
                    if matches:
                        st.sidebar.warning(f"Similarity: Use '{matches[0]}'?")
            except: pass
        f_opts = ["Jacquard Sherpa", "3-Layer Jacquard Sherpa", "Jacquard Rabbit Fur", "3-Layer Jacquard Rabbit Fur", "Rabbit Fur & Teddy", "Regular Rabbit Fur", "Premium Rabbit Fur", "High-Low Pile Fake Fur", "Curled Plush", "Coral Fleece", "Others..."]
        f_sel = st.selectbox("FABRIC MATERIAL", options=f_opts)
        f_type = st.text_input("CUSTOM FABRIC") if f_sel == "Others..." else f_sel
        f_p = st.text_input("* PRICE PER KG (RMB)")
        f_g = st.text_input("* FABRIC GSM")
    with st.expander("II. BACKING & CRAFT", expanded=True):
        b_l = st.multiselect("BACKING MATERIALS", ['felt', 'sponge', 'tpr', 'washable', 'cotton', 'pvc_dots', 'simulated_silicone_dots', 'silicone_dots', 'suede'], format_func=lambda x: UI_MAP[x])
        b_gsms = {b: st.text_input(f"* {UI_MAP[b]} GSM", "600") for b in b_l if b in ['felt', 'sponge', 'tpr', 'washable']}
        s_g_str = st.text_input("* SUEDE GSM", value="100") if 'suede' in b_l else "100"
        # Auto-show lamination fee for dot-type backings (require compounding craft)
        _dot_types = [b for b in b_l if b in ['pvc_dots', 'simulated_silicone_dots', 'silicone_dots']]
        if _dot_types:
            _lam_total = round(sum(0.65 for _ in _dot_types) * 1.06, 3)
            _names = ", ".join(UI_MAP[b] for b in _dot_types)
            st.markdown(f"<div style='background:#FBF6EC; border-left:3px solid #C9B289; padding:0.5rem 0.8rem; border-radius:4px; font-size:0.8rem; color:#7A6A4F; margin-bottom:0.6rem;'>🧩 Lamination Fee ({_names}): <strong>￥{_lam_total} /㎡</strong></div>", unsafe_allow_html=True)
        glue = st.checkbox("Apply Specialized Glue Coating", False)
        digital_print = st.checkbox("Apply Digital Printing", False)
    with st.expander("III. LOGISTICS & PACKING", expanded=True):
        sc1, sc2 = st.columns(2)
        with sc1:
            w_in = st.text_input("* WIDTH (cm)")
        with sc2:
            l_in = st.text_input("* LENGTH (cm)")
        q_in = st.text_input("* QUANTITY (PC)")
        st.divider()
        carton = st.toggle("Enable Master Carton", True)
        if carton:
            cc1, cc2, cc3 = st.columns(3)
            with cc1:
                supp = st.checkbox("Specified Supplier", False)
            with cc2:
                bag = st.checkbox("Include Moisture-proof Bag", True, help="Carton liner bag. Area = (L+W+40)×(W+H+100) mm² → ㎡, priced at ￥1.35/㎡, cost shared across PCS PER BOX.")
            with cc3:
                des = st.checkbox("Include Silica Desiccant", True)
            pe = st.checkbox("Include Individual PE Bag", False, help="Per-roll PE bag. Area = (RollLen+100)×(Dia×π+50) mm² → ㎡, priced at ￥0.65/㎡, charged per piece.")
            box_q = st.text_input("* PCS PER BOX", "6")
            # Line 1: Reference Carton Size (always shown)
            _ref_box = "Fill Width / Length / PCS to preview"
            try:
                if w_in.strip() and l_in.strip() and box_q.strip():
                    _prev = calculate_quote({
                        "width_cm": float(w_in), "length_cm": float(l_in),
                        "qty": 1, "fabric_gsm": float(f_g) if f_g.strip() else 450,
                        "fabric_price_kg": float(f_p) if f_p.strip() else 20,
                        "backing_list": b_l, "backing_gsms": {k: float(v) for k, v in b_gsms.items()},
                        "suede_gsm": float(s_g_str), "pcs_per_box": int(box_q),
                        "need_carton": True
                    })
                    if "error" not in _prev:
                        _ref_box = f"{_prev.get('box')} mm"
            except Exception:
                pass
            st.markdown(f"<div style='background:#FBF6EC; border-left:3px solid #C9B289; padding:0.5rem 0.8rem; border-radius:4px; font-size:0.8rem; color:#7A6A4F; margin-bottom:0.6rem;'>📦 Reference Carton Size: <strong>{_ref_box}</strong></div>", unsafe_allow_html=True)
            # Line 2: Manual Carton Size toggle
            manual_box = st.checkbox("Manual Carton Size")
            if manual_box:
                m1, m2, m3 = st.columns(3)
                with m1: box_l = m1.text_input("L (mm)")
                with m2: box_w = m2.text_input("W (mm)")
                with m3: box_h = m3.text_input("H (mm)")
            else:
                box_l = box_w = box_h = None
        else: pe, supp, bag, des, box_q = st.checkbox("PE Bag Packing Only", True), False, False, False, "1"; box_l = box_w = box_h = None
        st.divider()
        accs = st.multiselect("ACCESSORIES", ['wash', 'woven', 'tag', 'u_card', 'waist_s', 'waist_m', 'waist_l'], format_func=lambda x: UI_MAP[x])
        spec_acc = st.checkbox("Specified Accessory Premiums", False)
    
    if st.button("EXECUTE QUOTATION"):
        try:
            if not all([f_p.strip(), f_g.strip(), w_in.strip(), l_in.strip(), q_in.strip()]):
                st.error("Required Fields Missing.")
                st.stop()
            w_s_type = 'small' if 'waist_s' in accs else ('medium' if 'waist_m' in accs else ('large' if 'waist_l' in accs else 'none'))
            payload = {
                "customer": cust_in if cust_in.strip() else "Private Client", "width_cm": float(w_in), "length_cm": float(l_in), "qty": int(q_in.replace(',','')),
                "fabric_gsm": float(f_g), "fabric_price_kg": float(f_p), "backing_list": b_l, "backing_gsms": {k: float(v) for k,v in b_gsms.items()}, 
                "suede_gsm": float(s_g_str), "exchange_rate": float(rate_sell), "bank_buy_rate": float(rate_buy), "pcs_per_box": int(box_q), 
                "specified_supplier": supp, "specified_acc": spec_acc, "acc_list": accs, "waist_seal": w_s_type, "need_carton": carton, 
                "need_bag": bag if carton else False, "need_desiccant": des if carton else False, "need_glue": glue, "need_digital_print": digital_print, "need_pe_bag": pe
            }
            if carton and manual_box: payload.update({"manual_box_l": float(box_l), "manual_box_w": float(box_w), "manual_box_h": float(box_h)})
            res = calculate_quote(payload)
            if "error" in res: st.error(f"Engine Error: {res['error']}")
            else:
                b_dtls = []
                for b in b_l:
                    if b == 'cotton':
                        b_dtls.append("Cotton(130g)")
                    elif b in ['pvc_dots', 'simulated_silicone_dots', 'silicone_dots']:
                        b_dtls.append(f"{UI_MAP[b]}(50g)")
                    elif b in ['felt', 'sponge', 'tpr', 'washable']:
                        b_dtls.append(f"{UI_MAP[b]}({int(float(payload['backing_gsms'].get(b, '600')))}g)")
                    elif b == 'suede':
                        b_dtls.append(f"{UI_MAP[b]}({int(float(s_g_str))}g)")
                    else:
                        b_dtls.append(UI_MAP[b])
                if carton:
                    pkg_parts = ["Carton"]
                    if bag:
                        pkg_parts.append("Moisture-proof Bag")
                    if pe:
                        pkg_parts.append("PE Bag")
                    if des:
                        pkg_parts.append("Desiccant")
                    pkg_desc = " + ".join(pkg_parts)
                else:
                    pkg_desc = "PE Bag" if pe else "No Outer Packing"
                record = {
                    "Date": res['date'], "Customer": payload["customer"], "Size": f"{w_in}x{l_in}cm", "Qty": f"{q_in} PC",
                    "Fabric": f"{f_type} {f_g}gsm (￥{f_p}/kg)", "Backing": ", ".join(b_dtls),
                    "Acc/Pkg": f"{', '.join([UI_MAP[a] for a in accs]) if accs else 'No Accessories'} | {pkg_desc}",
                    "RMB/㎡": f"￥{res['sqm_price']}", "RMB/pc": f"￥{res['pc_price']}", "BankRate": res['ex_buy'], 
                    "Refund/㎡": f"${res['usd_tax_refund_sqm']}", "Refund/pc": f"${res['usd_tax_refund_pc']}",
                    "FOB/㎡": f"${res['usd_sqm']}", "FOB/pc": f"${res['usd_pc']}", "Loss": res['loss'], "Profit": res['profit_pct'],
                    "RMB Cost/㎡": f"￥{res['total_sqm_cost']}", "RMB Cost/pc": f"￥{res['total_pc_cost']}", "Box": res['box']
                }
                with open(HISTORY_FILE, 'a', encoding='utf-8') as f:
                    f.write(json.dumps(record, ensure_ascii=False) + "\n")
                st.session_state.final_res_v52 = res
                st.session_state.final_client_v52 = payload["customer"]
                st.session_state.celebrate = True
        except Exception as e: st.error(f"Input Fault: {e}")

with col_out:
    st.markdown("## Quotation Board")
    if st.session_state.get("celebrate", False):
        st.markdown("""
            <style>
                @keyframes hl-burst {
                    0% { transform: translate(0,0) scale(0); opacity: 1; }
                    70% { opacity: 1; }
                    100% { transform: translate(var(--dx), var(--dy)) scale(1); opacity: 0; }
                }
                .hl-fw { position: fixed; top: 38%; left: 60%; width: 0; height: 0; z-index: 99999; pointer-events: none; }
                .hl-fw span {
                    position: absolute; width: 7px; height: 7px; border-radius: 50%;
                    background: radial-gradient(circle, #E8CfA0 0%, #B89B72 70%);
                    box-shadow: 0 0 6px rgba(184,155,114,0.8);
                    animation: hl-burst 1.5s ease-out forwards;
                }
            </style>
            <div class="hl-fw">
                <span style="--dx:60px;--dy:-30px;animation-delay:0s;"></span>
                <span style="--dx:-55px;--dy:-45px;animation-delay:0.05s;"></span>
                <span style="--dx:70px;--dy:40px;animation-delay:0.1s;"></span>
                <span style="--dx:-65px;--dy:35px;animation-delay:0.08s;"></span>
                <span style="--dx:20px;--dy:-75px;animation-delay:0.12s;"></span>
                <span style="--dx:-15px;--dy:70px;animation-delay:0.04s;"></span>
                <span style="--dx:85px;--dy:-10px;animation-delay:0.15s;"></span>
                <span style="--dx:-80px;--dy:-5px;animation-delay:0.18s;"></span>
                <span style="--dx:40px;--dy:60px;animation-delay:0.2s;"></span>
                <span style="--dx:-35px;--dy:-60px;animation-delay:0.22s;"></span>
                <span style="--dx:0px;--dy:-90px;animation-delay:0.1s;"></span>
                <span style="--dx:5px;--dy:85px;animation-delay:0.16s;"></span>
            </div>
        """, unsafe_allow_html=True)
        st.session_state.celebrate = False
    if "final_res_v52" in st.session_state:
        r = st.session_state.final_res_v52
        st.markdown(f"#### CLIENT: {st.session_state.final_client_v52}")
        st.metric("FOB UNIT (USD)", f"${r['usd_pc']}")
        st.table({"METRICS": ["RMB/㎡", "RMB/PC", "FOB/㎡", "REFUND/㎡", "FOB/PC", "REFUND/PC"], "RESULTS": [f"￥{r['sqm_price']}", f"￥{r['pc_price']}", f"${r['usd_sqm']}", f"${r['usd_tax_refund_sqm']}", f"${r['usd_pc']}", f"${r['usd_tax_refund_pc']}"]})
        with st.expander("AUDIT & LOGISTICS LOG"):
            st.markdown(f"<p style='color: #B89B72;'>PRODUCT COST: ￥{r['total_sqm_cost']} /㎡</p>", unsafe_allow_html=True)
            st.markdown(f"<p style='color: #B89B72;'>PRODUCT COST: ￥{r['total_pc_cost']} /pc</p>", unsafe_allow_html=True)
            st.write(f"Fabric Loss Factor: {r['loss']}")
            st.write(f"Margin Applied: {r['profit_pct']}")
    else: st.info("System primed. Please configure parameters to generate a premium quote.")

st.divider()
st.caption("Hileewoo Edition V52.0 | Robust Financial Logic | Master Calibration")
