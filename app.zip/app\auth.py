"""
Hileewoo Quoting - authentication module (stdlib only).

Model:
  - The admin maintains a users.json hosted on GitHub (public dist repo).
  - Each user record: username, salt, pwd_hash (PBKDF2), role, status.
  - On login, this module fetches users.json over HTTPS and verifies the
    password locally. On success it writes a signed local cache so the app
    keeps working offline for GRACE_DAYS.

Security notes:
  - Passwords are never stored in plain text; PBKDF2-HMAC-SHA256, 200k iters.
  - The offline cache is HMAC-signed with a device-derived key, so a user
    cannot hand-edit the cache to extend their own access or un-suspend.
  - This deters non-technical users. Someone who edits the Python source can
    still bypass it (documented limitation of any client-side scheme).
"""
import base64
import hashlib
import hmac
import json
import os
import ssl
import time
import urllib.request

GRACE_DAYS = 7
PBKDF2_ITERS = 200_000
HTTP_TIMEOUT = 8

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("HILEEWOO_DATA_DIR") or APP_DIR
CACHE_FILE = os.path.join(DATA_DIR, ".auth_cache.json")


# ---------- password helpers ----------
def hash_password(password, salt=None):
    """Return (salt_b64, hash_b64) for a plaintext password."""
    if salt is None:
        salt = os.urandom(16)
    elif isinstance(salt, str):
        salt = base64.b64decode(salt)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERS)
    return base64.b64encode(salt).decode(), base64.b64encode(dk).decode()


def verify_password(password, salt_b64, hash_b64):
    _, calc = hash_password(password, salt_b64)
    return hmac.compare_digest(calc, hash_b64)


# ---------- users.json fetch ----------
def _candidate_urls(cfg):
    """
    Multiple channels for resilience in regions where raw.githubusercontent.com
    is blocked/unstable. Tried in order; first success wins.
    - ghproxy: real-time proxy of raw (no cache delay) -> best for instant suspend
    - jsdelivr CDNs: very reliable but cached ~12h -> fallback only
    - official raw: last resort
    A timestamp query busts caches where the host honors it.
    """
    owner = cfg.get("github_owner", "")
    repo = cfg.get("github_repo", "")
    ts = int(time.time())
    raw = f"raw.githubusercontent.com/{owner}/{repo}/main/users.json"
    return [
        f"https://ghproxy.net/https://{raw}?t={ts}",
        f"https://gh-proxy.com/https://{raw}?t={ts}",
        f"https://gcore.jsdelivr.net/gh/{owner}/{repo}@main/users.json",
        f"https://fastly.jsdelivr.net/gh/{owner}/{repo}@main/users.json",
        f"https://cdn.jsdelivr.net/gh/{owner}/{repo}@main/users.json",
        f"https://{raw}?t={ts}",
    ]


def fetch_users(cfg):
    """Return (users_dict, online_bool). Tries channels in order; first OK wins."""
    ctx = ssl.create_default_context()
    for url in _candidate_urls(cfg):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Hileewoo-Auth"})
            with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT, context=ctx) as r:
                data = json.loads(r.read().decode("utf-8"))
            users = {u["username"]: u for u in data.get("users", [])}
            if users:
                return users, True
        except Exception:
            continue
    return {}, False


# ---------- offline cache (HMAC-signed) ----------
def _device_key():
    """A stable per-device secret used to sign the offline cache."""
    seed = (os.environ.get("COMPUTERNAME", "") + "|" +
            os.environ.get("USERNAME", "") + "|hileewoo-auth-v1")
    return hashlib.sha256(seed.encode("utf-8")).digest()


def _sign(payload_str):
    return base64.b64encode(hmac.new(_device_key(), payload_str.encode("utf-8"),
                                     hashlib.sha256).digest()).decode()


def write_cache(username, role):
    payload = {"username": username, "role": role, "ts": int(time.time())}
    payload_str = json.dumps(payload, sort_keys=True)
    record = {"payload": payload, "sig": _sign(payload_str)}
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(record, f)
    except Exception:
        pass


def read_cache():
    """Return (username, role) if a valid, unexpired, untampered cache exists."""
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            record = json.load(f)
        payload = record["payload"]
        payload_str = json.dumps(payload, sort_keys=True)
        if not hmac.compare_digest(_sign(payload_str), record.get("sig", "")):
            return None, None  # tampered
        age_days = (time.time() - payload["ts"]) / 86400.0
        if age_days > GRACE_DAYS:
            return None, None  # expired
        return payload["username"], payload["role"]
    except Exception:
        return None, None


def clear_cache():
    try:
        os.remove(CACHE_FILE)
    except Exception:
        pass


# ---------- main entry ----------
def authenticate(username, password, cfg):
    """
    Returns (ok: bool, role: str, message: str).
    Online: verify against users.json. Offline: fall back to signed cache.
    """
    username = (username or "").strip()
    if not username or not password:
        return False, "", "请输入账号和密码。"

    users, online = fetch_users(cfg)

    if online:
        rec = users.get(username)
        if not rec:
            return False, "", "账号不存在。"
        if rec.get("status", "active") != "active":
            return False, "", "该账号已被停用，请联系管理员。"
        if not verify_password(password, rec.get("salt", ""), rec.get("pwd_hash", "")):
            return False, "", "密码错误。"
        role = rec.get("role", "user")
        write_cache(username, role)
        return True, role, "登录成功。"

    # Offline: only allow if a valid signed cache for THIS user exists.
    c_user, c_role = read_cache()
    if c_user == username:
        return True, c_role, "离线模式（宽限期内）登录成功。"
    return False, "", "当前无法联网验证，且无有效离线凭证。请连网后重试。"
