import streamlit as st
import os
import json
import pandas as pd
from datetime import datetime
import io

# V52.0 - THE DEFINITIVE MASTERPIECE: GOLD VERSION
# 100% Geometric Alignment | Zero Flicker | Zero Compound Semicolon Logic
st.set_page_config(
    page_title="Hileewoo Archive", 
    page_icon="📊", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- 1. Hileewoo Styling ---
st.markdown("""
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-lux: #F9F8F6;
            --sidebar-lux: #FFFFFF;
            --text-dark: #1A1A1A;
            --accent-gold: #B89B72;
            --border-lux: #E0DDD5;
        }
        
        [data-testid="stSidebarNav"]::before {
            content: "HILEEWOO SYSTEM";
            margin-left: 20px;
            margin-top: 30px;
            font-family: 'Playfair Display', serif !important;
            font-weight: 700 !important;
            font-size: 1.6rem;
            color: var(--text-dark);
            display: block;
            white-space: nowrap;
        }
        
        [data-testid="stSidebarNav"]::after {
            content: "📊 V52.0 Professional Edition";
            margin-left: 20px;
            margin-top: 5px;
            font-family: 'Montserrat', sans-serif !important;
            font-size: 0.6rem;
            color: #4A4A4A;
            display: block;
            margin-bottom: 2rem;
        }

        [data-testid="stSidebar"] { background-color: var(--sidebar-lux); border-right: 1px solid var(--border-lux); }
        .main { background-color: var(--bg-lux); }
        [data-testid="stSidebarNav"] > ul { padding-top: 1rem; }
        div[data-testid="stSidebarNav"] > div:first-child { display: none; }
        
        h1, h2, h3 { font-family: 'Playfair Display', serif !important; color: var(--text-dark) !important; font-weight: 700 !important; }
        h2, h3 { font-size: 1.3rem !important; margin-bottom: 1.5rem !important; }
        
        div, p, label, .stMarkdown { font-family: 'Montserrat', sans-serif !important; color: #4A4A4A !important; }
        [data-testid="stMetricValue"] { color: var(--accent-gold) !important; font-family: 'Montserrat', sans-serif !important; font-size: 1.1rem !important; font-weight: 600 !important; }
        .stDataFrame { border-radius: 4px; overflow: hidden; border: 1px solid var(--border-lux); background: white; }
        
        /* ── ACTION BAR: flat text controls, same baseline ── */
        /* Target every layer Streamlit/BaseUI renders for button across versions */
        [data-testid="stMain"] .stButton button,
        [data-testid="stMain"] .stButton button:focus,
        [data-testid="stMain"] .stButton button:active,
        [data-testid="stMain"] .stButton button:hover,
        [data-testid="stMain"] .stDownloadButton button,
        [data-testid="stMain"] .stDownloadButton button:focus,
        [data-testid="stMain"] .stDownloadButton button:active,
        [data-testid="stMain"] .stDownloadButton button:hover,
        [data-testid="stMain"] [data-testid^="stBaseButton"] {
            background: transparent !important;
            background-color: transparent !important;
            border: 0 none transparent !important;
            border-width: 0 !important;
            border-style: none !important;
            border-color: transparent !important;
            border-radius: 0 !important;
            outline: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            font-family: 'Montserrat', sans-serif !important;
            font-weight: 600 !important;
            font-size: 0.65rem !important;
            letter-spacing: 0.08em !important;
            text-transform: uppercase !important;
            color: #1A1A1A !important;
            line-height: 1 !important;
            height: auto !important;
            min-height: 0 !important;
            width: auto !important;
            min-width: 0 !important;
            white-space: nowrap !important;
        }
        [data-testid="stMain"] .stButton button:hover p,
        [data-testid="stMain"] .stDownloadButton button:hover p { color: var(--accent-gold) !important; }
        /* DELETE trash icon: larger, dimmed default, red on hover */
        [data-testid="stMain"] .stButton button p { font-size: 1.05rem !important; opacity: 0.55; transition: opacity 0.15s ease, color 0.15s ease; }
        [data-testid="stMain"] .stButton button:hover p { opacity: 1; color: #C0392B !important; }
        /* All three action controls drop to the SAME line as SELECT ALL */
        [data-testid="stMain"] .stButton { margin-top: 2.95rem !important; }
        [data-testid="stMain"] .stDownloadButton { margin-top: 2.95rem !important; text-align: right !important; }
        /* EXPORT flush to the table's right edge (kill column + button right padding) */
        [data-testid="stMain"] .stDownloadButton, [data-testid="stMain"] .stDownloadButton button { padding-right: 0 !important; margin-right: 0 !important; }
        /* Kill right padding/gap on the LAST action-bar column so EXPORT reaches the table edge */
        [data-testid="stMain"] [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child {
            padding-right: 0 !important;
        }
        [data-testid="stMain"] [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:last-child [data-testid="stElementContainer"] {
            align-items: flex-end !important;
        }
        /* Checkbox baseline */
        [data-testid="stMain"] .stCheckbox { margin: 2.8rem 0 0 0 !important; }
        [data-testid="stMain"] .stCheckbox label { align-items: center !important; margin: 0 !important; }

        
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        header { background: rgba(0,0,0,0) !important; }
    </style>
""", unsafe_allow_html=True)

# Data dir: env var (portable package) takes priority; dev fallback = parent of pages/
_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DATA_DIR = os.environ.get("HILEEWOO_DATA_DIR") or _APP_DIR
os.makedirs(_DATA_DIR, exist_ok=True)
HISTORY_FILE = os.path.join(_DATA_DIR, "quotes_history.jsonl")

with st.sidebar:
    st.markdown("""
        <div style='margin-top:1.5rem; margin-left:4px;'>
            <div style="font-family:'Playfair Display', serif; font-weight:700; font-size:1.6rem; color:#1A1A1A; white-space:nowrap;">HILEEWOO SYSTEM</div>
            <div style="font-family:'Montserrat', sans-serif; font-size:0.6rem; color:#4A4A4A; margin-top:4px; margin-bottom:1rem; letter-spacing:0.05em;">V52.6 PROFESSIONAL EDITION</div>
        </div>
    """, unsafe_allow_html=True)
    try:
        st.page_link("AutoQuoting.py", label="AutoQuoting", icon=":material/calculate:")
        st.page_link("pages/1_Quotation_History_Query.py", label="Quotation History Query", icon=":material/database:")
    except Exception:
        pass
    st.divider()

def render_empty_state(title="Your Archive Awaits", subtitle="No quotations have been recorded yet"):
    st.markdown(f"""
        <div style='display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:14vh 1rem 6vh 1rem;'>
            <div style='font-size:3.2rem; line-height:1; margin-bottom:1.6rem; opacity:0.85;'>🗂️</div>
            <div style="font-family:'Playfair Display', serif; font-weight:700; font-size:2rem; color:#1A1A1A; letter-spacing:-0.01em; margin-bottom:0.6rem;">{title}</div>
            <div style="font-family:'Montserrat', sans-serif; font-size:0.85rem; color:#8A8478; letter-spacing:0.04em; max-width:420px; margin-bottom:0.4rem;">{subtitle}</div>
            <div style="width:48px; height:2px; background:#B89B72; margin:1.6rem 0;"></div>
            <div style="font-family:'Montserrat', sans-serif; font-size:0.8rem; color:#4A4A4A; letter-spacing:0.05em;">
                Head to <strong style='color:#B89B72;'>AutoQuoting</strong> to generate your first quotation.<br>
                Every executed quote is automatically archived here.
            </div>
        </div>
    """, unsafe_allow_html=True)

def normalize_dataframe(df):
    mapping = {
        "日期 (Date)": "Date", "客户 (Customer)": "Customer", "规格 (Size)": "Size", "数量 (Qty)": "Qty",
        "面料细节 (Fabric)": "Fabric", "底背细节 (Backing)": "Backing", "辅料包装细节": "Packing", "Acc/Pkg": "Packing",
        "美金结汇汇率": "BankRate", "退税/㎡": "Refund/㎡", "退税/pc": "Refund/pc",
        "RMB/㎡": "RMB/㎡", "RMB/pc": "RMB/pc", "FOB/㎡": "FOB/㎡", "FOB/pc": "FOB/pc",
        "损耗率": "Loss", "利润率": "Profit", "箱规 (Box)": "Box"
    }
    df = df.rename(columns=mapping)
    df = df.loc[:, ~df.columns.duplicated()].copy()
    return df

def save_history(df):
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        for _, row in df.iterrows():
            f.write(json.dumps(row.to_dict(), ensure_ascii=False) + "\n")

if os.path.exists(HISTORY_FILE):
    all_history_data = []
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8-sig', errors='replace') as f:
            for line in f:
                if line.strip():
                    try:
                        all_history_data.append(json.loads(line))
                    except:
                        continue
    except:
        pass
    
    if all_history_data:
        df_raw = pd.DataFrame(all_history_data)
        df_norm = normalize_dataframe(df_raw)
        df_norm = df_norm.fillna("-")
        if "RMB/㎡" in df_norm.columns:
            df_norm = df_norm[df_norm["RMB/㎡"].astype(str).str.contains("￥|锟", na=False)].copy()
        
        if df_norm.empty:
            render_empty_state()
            st.stop()

        st.markdown("## Quotation Archive")
        st.markdown("### Performance Overview")
        m1, m2, m3 = st.columns(3)
        m1.metric("ARCHIVED QUOTES", len(df_norm))
        m2.metric("UNIQUE CLIENTS", len(df_norm['Customer'].unique()) if 'Customer' in df_norm.columns else "-")
        m3.metric("LATEST UPDATE", df_norm['Date'].iloc[-1] if 'Date' in df_norm.columns else "-")
        
        st.divider()
        f_l, f_m, f_r = st.columns([0.3, 0.45, 0.25])
        with f_l:
            s_cust = st.selectbox("SEARCH BY CLIENT", ["All Clients"] + sorted(df_norm['Customer'].unique().tolist()))
        with f_m:
            s_key = st.text_input("DEEP ARCHIVE SEARCH", placeholder="Search...")
        with f_r:
            row_sz = st.selectbox("ROWS PER PAGE", [10, 20, 50, 100], index=1)
        
        df_filtered = df_norm.iloc[::-1].copy()
        if s_cust != "All Clients":
            df_filtered = df_filtered[df_filtered["Customer"] == s_cust]
        if s_key:
            df_filtered = df_filtered[df_filtered.apply(lambda r: r.astype(str).str.contains(s_key, case=False).any(), axis=1)]
        
        action_bar = st.container()

        ordered_keys = ["Date", "Customer", "Size", "Qty", "RMB/㎡", "RMB/pc", "FOB/㎡", "Refund/㎡", "FOB/pc", "Refund/pc", "Fabric", "Backing", "Packing", "Box"]
        final_disp_cols = [c for c in ordered_keys if c in df_norm.columns]
        df_with_sel = df_filtered[final_disp_cols].copy()
        # SELECT ALL: pre-fill the SELECT column based on the master toggle
        select_all = st.session_state.get("select_all_toggle", False)
        df_with_sel.insert(0, "SELECT", select_all)
        
        edited_df = st.data_editor(
            df_with_sel, use_container_width=True, height=min(600, 35 * row_sz + 100),
            num_rows="fixed", hide_index=True, key="history_editor_v52_6"
        )
        sel_idx = edited_df[edited_df["SELECT"] == True].index
        
        out_buf = io.BytesIO()
        with pd.ExcelWriter(out_buf, engine='xlsxwriter') as wr:
            df_filtered[final_disp_cols].to_excel(wr, index=False)

        with action_bar:
            col_sel, col_del, col_mid, col_right = st.columns([0.16, 0.20, 0.39, 0.25])
            with col_sel:
                st.checkbox("SELECT ALL", key="select_all_toggle")
            with col_del:
                if not sel_idx.empty:
                    if st.button("🗑️", key="del_btn", help="Delete selected records"):
                        df_new = df_norm.drop(sel_idx)
                        save_history(df_new)
                        st.session_state.select_all_toggle = False
                        st.rerun()
            with col_right:
                st.download_button("EXPORT", data=out_buf.getvalue(), file_name=f"Archive_{datetime.now().strftime('%Y%m%d')}.xlsx", key="export_btn")

        st.divider()
        st.markdown("## Technical Record Inspection")
        if not df_filtered.empty:
            df_for_sel = df_filtered.copy()
            df_for_sel['id'] = df_for_sel['Date'].astype(str) + " | " + df_for_sel['Customer'].astype(str) + " | " + df_for_sel.index.astype(str)
            selected_id_val = st.selectbox("SELECT QUOTATION ID", df_for_sel['id'].tolist())
            original_idx = int(selected_id_val.split("|")[-1].strip())
            d = df_norm.loc[original_idx].to_dict()
            ic1, ic2 = st.columns(2)
            with ic1:
                st.markdown(f"**Fabric**: {d.get('Fabric', '-')}")
                st.markdown(f"**Backing**: {d.get('Backing', '-')}")
                st.markdown(f"**Packing**: {d.get('Packing', '-')}")
            with ic2:
                st.markdown(f"**RMB Cost/㎡**: {d.get('RMB Cost/㎡', '-')}")
                st.markdown(f"**Efficiency Loss**: {d.get('Loss', '-')}")
                st.markdown(f"**Applied Margin**: {d.get('Profit', '-')}")
    else:
        render_empty_state()
        st.stop()
else:
    render_empty_state(title="Your Archive Awaits", subtitle="The archive has not been initialized yet")
    st.stop()
st.divider()
st.caption("Hileewoo Edition V52.0 | Robust Financial Logic | Master Calibration")
