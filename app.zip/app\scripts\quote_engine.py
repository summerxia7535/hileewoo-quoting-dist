import sys
import json
import math
from datetime import datetime

def calculate_quote(params):
    # 1. Geometry
    w = params.get('width_cm', 100)
    l = params.get('length_cm', 150)
    area = (w * l) / 10000.0
    peri = (w + l) * 2 / 100.0
    r_w_mm, r_l_mm = min(w, l) * 10, max(w, l) * 10

    # 2. Fabric Logic
    f_gsm = params.get('fabric_gsm', 450)
    f_price = params.get('fabric_price_kg', 21.0)
    
    if area < 0.64:
        b_loss, p_rate = 0.09, 1.0
    elif area < 0.96:
        b_loss, p_rate = 0.10, 0.9
    else:
        b_loss, p_rate = 0.12, 0.8
        
    e_loss = 0.0
    if area > 3.84: e_loss += 0.01
    if f_gsm >= 800: e_loss += 0.02
    elif f_gsm > 550: e_loss += 0.01
        
    t_loss = b_loss + e_loss
    f_cost_sqm = f_price * (f_gsm / 1000.0) * (1 + t_loss)

    # 3. Backing
    b_list = params.get('backing_list', ['felt'])
    b_gsms = params.get('backing_gsms', {})
    s_gsm = params.get('suede_gsm', 100)
    b_prices = {'felt': 4.6, 'sponge': 18.5, 'tpr': 8.0, 'washable': 7.0, 'cotton': 1.3, 'pvc_dots': 0.85, 'simulated_silicone_dots': 1.2, 'silicone_dots': 2.0, 'suede': 2.8, 'glue': 1.0}
    lam_prices_base = {'felt': 0.65, 'suede': 0.8, 'cotton': 0.65, 'washable': 1.0, 'sponge': 0.65, 'tpr': 0.65, 'pvc_dots': 0.65, 'simulated_silicone_dots': 0.65, 'silicone_dots': 0.65}
    
    t_b_raw, t_lam_raw = 0.0, 0.0
    for b in b_list:
        if b == 'suede': t_b_raw += max(2.8, 2.8 / 100.0 * s_gsm)
        elif b in ['felt', 'sponge', 'tpr', 'washable']: t_b_raw += (b_prices[b] * float(b_gsms.get(b, 600)) / 1000.0)
        else: t_b_raw += b_prices.get(b, 0.0)
        if b in lam_prices_base: t_lam_raw += lam_prices_base[b]
    if params.get('need_glue', False): t_b_raw += b_prices['glue']
    
    b_cost_sqm_final = t_b_raw * 1.06
    lam_fee_sqm_final = t_lam_raw * 1.06
    
    # 3b. Digital Printing (2.0/sqm base, +6% loss)
    digital_print_sqm = 2.0 * 1.06 if params.get('need_digital_print', False) else 0.0

    # 4. Processing
    proc_cost_sqm = (p_rate * peri) / area
    prod_cost_sqm_base = f_cost_sqm + b_cost_sqm_final + lam_fee_sqm_final + proc_cost_sqm + digital_print_sqm
    
    qty = params.get('qty', 1)
    if (area * qty) < 2000: profit = 0.12
    elif (area * qty) < 4800: profit = 0.08
    elif (area * qty) < 10000: profit = 0.05
    elif (area * qty) < 17000: profit = 0.01
    else: profit = 0.03
    
    # 5. Diameter
    w_s = params.get('waist_seal', 'none')
    if 'suede' in b_list:
        if f_gsm < 550: d_val = 90 if area <= 0.54 else (110 if area >= 0.96 else 90 + 20*(area-0.54)/0.42)
        elif f_gsm < 800: d_val = 100 if area <= 0.54 else (120 if area >= 0.96 else 100 + 20*(area-0.54)/0.42)
        else: d_val = 110 if area <= 0.54 else (130 if area >= 0.96 else 110 + 20*(area-0.54)/0.42)
    else:
        d_val = 140 if w_s == 'medium' else (160 if w_s == 'large' else 130)
        
    # 6. Packing
    spec_supp = params.get('specified_supplier', False)
    manual_l = params.get('manual_box_l')
    manual_w = params.get('manual_box_w')
    manual_h = params.get('manual_box_h')
    p_box = max(1, params.get('pcs_per_box', 4))
    
    if manual_l and manual_w and manual_h:
        dims = sorted([manual_l, manual_w, manual_h], reverse=True)
        b_l, b_w, b_h = dims[0], dims[1], dims[2]
    else:
        # Auto optimal packing: find the most balanced cols x rows grid for p_box rolls
        best_cols, best_rows, best_score = p_box, 1, None
        for rows in range(1, p_box + 1):
            cols = math.ceil(p_box / rows)
            waste = cols * rows - p_box
            balance = abs(cols - rows)
            score = (waste, balance)
            if best_score is None or score < best_score:
                best_score = score
                best_cols, best_rows = cols, rows
        # Raw carton dimensions (mm): roll axis + grid cross-section
        roll_axis = r_w_mm + 20
        cross_a = best_cols * d_val + 10
        cross_b = best_rows * d_val + 10
        # Sort so Length >= Width >= Height
        dims = sorted([roll_axis, cross_a, cross_b], reverse=True)
        b_l, b_w, b_h = dims[0], dims[1], dims[2]
    
    b_sqm = ((b_l + b_w)*2 + 80) * (b_w + b_h + 40) / 1000000.0
    bg_sqm = (b_l + b_w + 40) * (b_w + b_h + 100) / 1000000.0
    
    t_pack_box = 0
    if params.get('need_carton', True):
        t_pack_box += b_sqm * (3.5 if spec_supp else 2.5)
        if params.get('need_bag', True): t_pack_box += bg_sqm * 1.35
        if params.get('need_desiccant', True): t_pack_box += (0.2 if spec_supp else 0.05)
    
    pack_pc = t_pack_box / p_box
    # Individual PE bag wraps each roll; available with or without a master carton
    pe_pc = (r_l_mm + 100) * (d_val * math.pi + 50) / 1000000.0 * 0.65 if params.get('need_pe_bag', False) else 0.0

    # 7. Accessories
    # Specified mode: waist seals charged at 2x the normal price
    a_spec = {'wash': 0.1, 'woven': 0.11, 'tag': 0.09, 'u_card': 0.6, 'waist_s': 0.6, 'waist_m': 1.0, 'waist_l': 1.4}
    a_norm = {'wash': 0.06, 'woven': 0.1, 'tag': 0.03, 'u_card': 0.4, 'waist_m': 0.5, 'waist_l': 0.7, 'waist_s': 0.3}
    acc_pc = sum([(a_spec if params.get('specified_acc') else a_norm).get(a, 0) for a in params.get('acc_list', [])])

    # 8. Final Calculation
    total_piece_cost = (prod_cost_sqm_base * area) + acc_pc + pack_pc + pe_pc
    total_sqm_cost = total_piece_cost / area
    
    price_pc = total_piece_cost * (1 + profit)
    sqm_price = total_sqm_cost * (1 + profit)
    ex_sell = params.get('exchange_rate', 6.76)
    ex_buy = params.get('bank_buy_rate', 6.70)

    # 9. Tax Refund (USD)
    usd_tax_refund_sqm = (total_sqm_cost / 1.13 * 0.13) / ex_buy
    usd_tax_refund_pc = (total_piece_cost / 1.13 * 0.13) / ex_buy

    return {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "total_sqm_cost": round(total_sqm_cost, 3), 
        "total_pc_cost": round(total_piece_cost, 3), 
        "lam_fee_sqm": round(lam_fee_sqm_final, 3), 
        "digital_print_sqm": round(digital_print_sqm, 3), 
        "profit_pct": f"{int(profit*100)}%", "profit_val": round(total_piece_cost * profit, 3),
        "sqm_price": round(sqm_price, 3), "pc_price": round(price_pc, 3),
        "usd_tax_refund_sqm": round(usd_tax_refund_sqm, 3),
        "usd_tax_refund_pc": round(usd_tax_refund_pc, 3),
        "usd_pc": round(price_pc / ex_sell, 3), 
        "usd_sqm": round(sqm_price / ex_sell, 3),
        "box": f"{int(b_l)}x{int(b_w)}x{int(b_h)}" if params.get('need_carton', True) else "N/A",
        "loss": f"{int(t_loss*100)}%", "dia": round(d_val, 1), "ex": ex_sell, "ex_buy": ex_buy
    }

if __name__ == "__main__":
    try: print(json.dumps(calculate_quote(json.loads(sys.argv[1]))))
    except Exception as e: print(json.dumps({"error": str(e)}))
