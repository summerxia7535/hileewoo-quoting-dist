"""
Hileewoo Quoting - self-updater (stdlib only, runs before Streamlit starts).

Flow:
  1. Read local app/VERSION and app/update_config.json.
  2. Query GitHub Releases "latest" API for the newest tag + app.zip asset.
  3. If remote version > local, download app.zip, extract to a temp dir,
     then atomically replace the app/ folder (data/ is OUTSIDE app/, never touched).
  4. Any failure (offline, timeout, bad zip) -> print a note and exit 0 so the
     launcher still starts the current version.

Layout assumed at runtime:
  <ROOT>/app/        <- this file lives here; gets replaced on update
  <ROOT>/data/       <- preserved
  <ROOT>/python/     <- preserved
"""
import json
import os
import shutil
import ssl
import sys
import tempfile
import time
import urllib.request
import zipfile

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(APP_DIR)
VERSION_FILE = os.path.join(APP_DIR, "VERSION")
CONFIG_FILE = os.path.join(APP_DIR, "update_config.json")
TIMEOUT = 8  # seconds; keep startup snappy when network is slow


def _read_local_version():
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return "0"


def _read_config():
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _ver_tuple(v):
    # "52.7" / "v52.7.1" -> (52, 7, 1); non-numeric parts become 0
    v = str(v).lstrip("vV").strip()
    parts = []
    for p in v.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def _is_newer(remote, local):
    return _ver_tuple(remote) > _ver_tuple(local)


def _candidate_urls(owner, repo, filename, bust=True):
    """
    Multiple channels for files committed to the dist repo ROOT, for resilience
    where raw.githubusercontent.com / github.com are blocked/unstable.
    Order: ghproxy (real-time) -> jsdelivr CDNs (cached) -> official raw.
    """
    ts = int(time.time())
    q = f"?t={ts}" if bust else ""
    raw = f"raw.githubusercontent.com/{owner}/{repo}/main/{filename}"
    return [
        f"https://ghproxy.net/https://{raw}{q}",
        f"https://gh-proxy.com/https://{raw}{q}",
        f"https://gcore.jsdelivr.net/gh/{owner}/{repo}@main/{filename}",
        f"https://fastly.jsdelivr.net/gh/{owner}/{repo}@main/{filename}",
        f"https://cdn.jsdelivr.net/gh/{owner}/{repo}@main/{filename}",
        f"https://{raw}{q}",
    ]


def _fetch_text(urls):
    ctx = ssl.create_default_context()
    for url in urls:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Hileewoo-Quoting-Updater"})
            with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
                return r.read().decode("utf-8").strip()
        except Exception:
            continue
    return None


def _download(urls, dest):
    ctx = ssl.create_default_context()
    for url in urls:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Hileewoo-Quoting-Updater"})
            with urllib.request.urlopen(req, timeout=60, context=ctx) as r, open(dest, "wb") as f:
                shutil.copyfileobj(r, f)
            if os.path.getsize(dest) > 0:
                return True
        except Exception:
            continue
    return False


def main():
    local = _read_local_version()
    try:
        cfg = _read_config()
    except Exception:
        print("[Update] config missing, skip.")
        return 0

    owner = cfg.get("github_owner", "")
    repo = cfg.get("github_repo", "")
    asset_name = cfg.get("asset_name", "app.zip")
    if not owner or owner == "YOUR_GITHUB_USERNAME" or not repo:
        print("[Update] GitHub not configured, skip.")
        return 0

    print(f"[Update] current v{local}, checking for updates...")
    remote = _fetch_text(_candidate_urls(owner, repo, "latest_version.txt"))
    if not remote:
        print("[Update] check skipped (offline / all channels failed).")
        return 0

    if not _is_newer(remote, local):
        print(f"[Update] already up to date (v{local}).")
        return 0

    print(f"[Update] new version v{remote} found, downloading...")
    tmp = tempfile.mkdtemp(prefix="hileewoo_upd_")
    zip_path = os.path.join(tmp, asset_name)
    extract_dir = os.path.join(tmp, "extracted")
    try:
        if not _download(_candidate_urls(owner, repo, asset_name), zip_path):
            print("[Update] download failed on all channels, keeping current version.")
            return 0
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(extract_dir)

        # The zip may contain files at root or under an inner "app/" folder.
        src = extract_dir
        inner = os.path.join(extract_dir, "app")
        if os.path.isdir(inner):
            src = inner
        # Sanity: must contain AutoQuoting.py
        if not os.path.exists(os.path.join(src, "AutoQuoting.py")):
            print("[Update] downloaded package invalid (no AutoQuoting.py), skip.")
            return 0

        # Backup current app/, then swap in the new files.
        backup = APP_DIR + "_old"
        if os.path.exists(backup):
            shutil.rmtree(backup, ignore_errors=True)
        # Copy new files over the live app/ (in-place to avoid locking issues on the
        # currently-running script's directory).
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(APP_DIR, item)
            if os.path.isdir(s):
                if os.path.exists(d):
                    shutil.rmtree(d, ignore_errors=True)
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
        print(f"[Update] updated to v{remote}.")
    except Exception as e:
        print(f"[Update] failed, keeping current version: {e}")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
